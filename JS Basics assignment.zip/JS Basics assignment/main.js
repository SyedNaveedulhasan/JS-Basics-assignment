// 1. Reverse a string without using the built-in reverse() method.
function reverseString(str) {
    let reversed = '';
    for (let i = str.length - 1; i >= 0; i--) {
      reversed += str[i];
    }
    return reversed;
  }
  
  console.log(reverseString("hello"));
  
  // 2. Count the number of vowels in a given string.
  function countVowels(str) {
    const vowels = 'aeiouAEIOU';
    let count = 0;
    for (let char of str) {
      if (vowels.includes(char)) {
        count++;
      }
    }
    return count;
  }
  
  console.log(countVowels("hello")); 
  
  // 3. Convert the first letter of each word in a sentence to uppercase.
  function capitalizeFirstLetter(sentence) {
    return sentence.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  }
  
  console.log(capitalizeFirstLetter("this is a sentence")); 
  
  // 4. Check if a string is a palindrome.
  function isPalindrome(str) {
    return str === str.split('').reverse().join('');
  }
  
  console.log(isPalindrome("racecar"));
  
  // 5. Find the sum of all positive numbers in an array.
  function sumOfPositiveNumbers(arr) {
    return arr.reduce((sum, num) => num > 0 ? sum + num : sum, 0);
  }
  
  console.log(sumOfPositiveNumbers([-1, 2, 3, -4, 5])); 
  
  // 6. Find the index of the first occurrence of a specific element in an array.
  function indexOfElement(arr, element) {
    for (let i = 0; i < arr.length; i++) {
      if (arr[i] === element) {
        return i;
      }
    }
    return -1;
  }
  
  console.log(indexOfElement([1, 2, 3, 4, 5], 3)); 
  
  // 7. Remove all duplicates from an array without built-in methods.
  function removeDuplicates(arr) {
    return arr.filter((item, index) => arr.indexOf(item) === index);
  }
  
  console.log(removeDuplicates([1, 2, 2, 3, 4, 4, 5]));
  
  // 8. Sort the array in ascending and descending without built-in methods.
  function sortAscending(arr) {
    return arr.slice().sort((a, b) => a - b);
  }
  
  function sortDescending(arr) {
    return arr.slice().sort((a, b) => b - a);
  }
  
  console.log(sortAscending([3, 1, 4, 1, 5, 9, 2, 6, 5])); 
  console.log(sortDescending([3, 1, 4, 1, 5, 9, 2, 6, 5]));
  
  // 9. Print all even numbers between 1 and 20 using a while loop.
  let num = 1;
  while (num <= 20) {
    if (num % 2 === 0) {
      console.log(num);
    }
    num++;
  }
  
  // 10. Calculate the factorial of a number using a do-while loop.
  function factorial(n) {
    let result = 1;
    let i = 1;
    do {
      result *= i;
      i++;
    } while (i <= n);
    return result;
  }
  
  console.log(factorial(5)); 
  
  // 11. Iterate through the properties of an object using a for-in loop.
  const obj = { a: 1, b: 2, c: 3 };
  for (let key in obj) {
    console.log(`${key}: ${obj[key]}`);
  }
  
  // 12. Loop through an array using a for-of loop and double each element.
  const numbers = [1, 2, 3, 4, 5];
  for (let num of numbers) {
    console.log(num * 2);
  }
  
  // 13. Check if a number is even or odd and return a corresponding message.
  function checkEvenOrOdd(num) {
    return num % 2 === 0 ? `${num} is even` : `${num} is odd`;
  }
  
  console.log(checkEvenOrOdd(5)); 
  
  // 14. Find the maximum of three numbers using nested ternary operators.
  function maxOfThree(a, b, c) {
    return a > b ? (a > c ? a : c) : (b > c ? b : c);
  }
  
  console.log(maxOfThree(5, 9, 3)); 
  
  // 15. Determine if a year is a leap year or not.
  function isLeapYear(year) {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  }
  
  console.log(isLeapYear(2024)); 
  